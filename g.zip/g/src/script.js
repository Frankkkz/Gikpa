<script>
  // Simulated data - replace with actual API calls in a real application
        const socialMediaData = {
            facebook: { followers:5000, engagement: 3.2 },
            twitter: { followers:8000, engagement: 2.7 },
            instagram: { followers:10000, engagement: 4.5 }
        };

        function updateDashboard() {
            document.getElementById('facebook-followers').textContent = socialMediaData.facebook.followers;
            document.getElementById('facebook-engagement').textContent = socialMediaData.facebook.engagement + '%';
            document.getElementById('twitter-followers').textContent = socialMediaData.twitter.followers;
            document.getElementById('twitter-engagement').textContent = socialMediaData.twitter.engagement + '%';
            document.getElementById('instagram-followers').textContent = socialMediaData.instagram.followers;
            document.getElementById('instagram-engagement').textContent = socialMediaData.instagram.engagement + '%';
        }

        // Call updateDashboard when the page loads
        window.onload = updateDashboard;
function schedulePost() {
    const content = document.getElementById('post-content').value;
    const platform = document.getElementById('platform-select').value;
    const scheduleTime = document.getElementById('schedule-time').value;
    
    // Add logic to store scheduled post
    const scheduledPost = { content, platform, scheduleTime };
    // You would typically send this to a server or store in local storage
    
    displayScheduledPost(scheduledPost);
}

function displayScheduledPost(post) {
    const scheduledPostsDiv = document.getElementById('scheduled-posts');
    const postElement = document.createElement('div');
    postElement.innerHTML = `
        <p><strong>${post.platform}</strong>: ${post.content}</p>
        <p>Scheduled for: ${post.scheduleTime}</p>
    `;
    scheduledPostsDiv.appendChild(postElement);
}
function populateContentCalendar() {
    const calendar = document.getElementById('content-calendar');
    // Simulate fetching scheduled posts
    const scheduledPosts = [
        { platform: 'Facebook', content: 'Check out our latest product!', date: '2023-06-15' },
        { platform: 'Twitter', content: 'Big announcement coming soon!', date: '2023-06-16' },
        { platform: 'Instagram', content: 'Behind the scenes look', date: '2023-06-17' }
    ];
    
    scheduledPosts.forEach(post => {
        const postElement = document.createElement('div');
        postElement.innerHTML = `
            <p><strong>${post.date}</strong> - ${post.platform}: ${post.content}</p>
        `;
        calendar.appendChild(postElement);
    });
}

// Call this function when the page loads
window.onload = function() {
    updateDashboard();
    populateContentCalendar();
};
function fetchPlatformContent(platform) {
    // Simulate API call to fetch content
    const content = [
        { id: 1, text: 'Sample post 1', likes: 10, comments: 5 },
        { id: 2, text: 'Sample post 2', likes: 15, comments: 3 }
    ];
    
    const contentDiv = document.getElementById(`${platform}-content`);
    content.forEach(post => {
        const postElement = document.createElement('div');
        postElement.innerHTML = `
            <p>${post.text}</p>
            <p>Likes: ${post.likes}, Comments: ${post.comments}</p>
            <button onclick="editPost('${platform}', ${post.id})">Edit</button>
            <button onclick="deletePost('${platform}', ${post.id})">Delete</button>
        `;
        contentDiv.appendChild(postElement);
    });
}

function editPost(platform, postId) {
    // Implement edit functionality
    console.log(`Editing post ${postId} on ${platform}`);
}

function deletePost(platform, postId) {
    // Implement delete functionality
    console.log(`Deleting post ${postId} from ${platform}`);
}

// Call this function for each platform when the page loads
window.onload = function() {
    updateDashboard();
    populateContentCalendar();
    fetchPlatformContent('facebook');
    fetchPlatformContent('twitter');
    fetchPlatformContent('instagram');
};
function login(event) {
    event.preventDefault();
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Implement actual authentication logic here
    // For demonstration, we'll use a simple check
    if (email === 'user@example.com' && password === 'password') {
        showAccountManagement();
        document.getElementById('user-name').textContent = 'User';
    } else {
        alert('Invalid credentials');
    }
}

function register(event) {
    event.preventDefault();
    const name = document.getElementById('reg-name').value;
    const email = document.getElementById('reg-email').value;
    const password = document.getElementById('reg-password').value;
    const confirmPassword = document.getElementById('reg-confirm-password').value;
    
    if (password !== confirmPassword) {
        alert('Passwords do not match');
        return;
    }
    
    // Implement actual registration logic here
    alert('Registration successful! Please login.');
    showLogin();
}

function showLogin() {
    document.getElementById('login-form').style.display = 'block';
    document.getElementById('registration-form').style.display = 'none';
    document.getElementById('account-management').style.display = 'none';
}

function showRegistration() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('registration-form').style.display = 'block';
    document.getElementById('account-management').style.display = 'none';
}

function showAccountManagement() {
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('registration-form').style.display = 'none';
    document.getElementById('account-management').style.display = 'block';
}

function logout() {
    // Implement logout logic here
    showLogin();
}

function changePassword(event) {
    event.preventDefault();
    const currentPassword = document.getElementById('current-password').value;
    const newPassword = document.getElementById('new-password').value;
    const confirmNewPassword = document.getElementById('confirm-new-password').value;
    
    if (newPassword !== confirmNewPassword) {
        alert('New passwords do not match');
        return;
    }
    
    // Implement password change logic here
    alert('Password changed successfully');
}
    </script>